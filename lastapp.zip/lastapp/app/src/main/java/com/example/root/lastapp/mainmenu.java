package com.example.root.lastapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;


public class mainmenu extends AppCompatActivity {

    private Button hostel_button, chat_button, city_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu_layout);

        hostel_button = (Button) findViewById(R.id.hostel_button2);
        city_button = (Button) findViewById(R.id.city_button);
        chat_button = (Button) findViewById(R.id.chat_button);

        hostel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mainmenu.this,hostel.class));
            }
        });

        city_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mainmenu.this,city.class));
            }
        });

        chat_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(mainmenu.this,Chat.class));
            }
        });


    }
}
