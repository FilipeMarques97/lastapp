package com.example.root.lastapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;



public class city extends AppCompatActivity {

    private Button museums, sights,clubs,cafe,back2;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city);

        museums = (Button) findViewById(R.id.museums_button);
        sights = (Button) findViewById(R.id.sights_button);
        clubs = (Button) findViewById(R.id.clubs_button);
        cafe = (Button) findViewById(R.id.cafe_button);
        sights = (Button) findViewById(R.id.back_main_layout);





        cafe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(city.this,cafe.class));
            }
        });

        sights.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(city.this,sights.class));
            }
        });

        clubs.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(city.this,clubs.class));
            }
        });

        museums.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(city.this,clubs.class));
            }
        });

        back2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



    }
}




